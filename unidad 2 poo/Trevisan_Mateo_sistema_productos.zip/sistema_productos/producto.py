
class Producto:
    def __init__(self, nombre, tipo, precio, stock):
        self.nombre = nombre
        self.tipo = tipo
        self.precio = precio
        self.__stock = 0
        self.set_stock(stock)
    
    def get_stock(self):
        return self.__stock
 
    def set_stock(self, nuevo_stock):
        if nuevo_stock >= 0:
            self.__stock = nuevo_stock
        else:
            print("Stock inválido")
 
    def mostrar_datos(self):
        print(" ")
        print("Nombre:",self.nombre,"\nTipo:",self.tipo,"\nPrecio:",self.precio,"\nStock:",self.__stock,)
  
    def vender(self, cantidad):
        print(" ")
        if cantidad <= 0:
            print("Cantidad invalida")
        elif cantidad <= self.__stock:
            self.__stock -= cantidad
            print("Venta realizada")
        else:
            print("Stock insuficiente")
    
    def reponer(self, cantidad):
        print(" ")
        if cantidad > 0:
             self.__stock = self.__stock + cantidad
             print("Reposición realizada")
        else:
            print("Cantidad inválida")

    def calcular_precio_final(self):
        return self.precio





