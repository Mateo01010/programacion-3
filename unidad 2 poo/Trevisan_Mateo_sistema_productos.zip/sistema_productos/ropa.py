from producto import Producto
class Ropa(Producto):
    def __init__(self,nombre,categoria,talle,precio,stock):
        super().__init__(nombre,"Ropa",precio,stock)
        self.talle = talle
        self.categoria = categoria

    def mostrar_datos(self):
        super().mostrar_datos()
        print("categoria:",self.categoria)

    def calcular_precio_final(self):
        return self.precio * 0.85
        
    def mostrar_talle(self):
        print("talle:",self.talle)