from producto import Producto
from alimento import Alimento
from electronico import Electronico
from ropa import Ropa

#ejercicio 1
leche = Alimento("Leche",1800,10,"6/11")
notebook = Electronico("notebook",800000,2,5)
cuaderno = Producto("cuaderno","objeto",5000,7)

productos = [leche,notebook,cuaderno]
for prod in productos:
    print(prod.calcular_precio_final())

#ejercicio 2
remera_azul = Ropa("Remera Azul","remera","10",40000,3)
medias_blancas = Ropa("medias blancas","medias","2",2000,10)

productos = [leche,notebook,cuaderno,remera_azul,medias_blancas]

#ejercicio 3
cuaderno.vender(2)
print("stock:",cuaderno.get_stock())
remera_azul.vender(4)
print("stock:",remera_azul.get_stock())
leche.reponer(5)
print("stock:",leche.get_stock())

for prod in productos:
   prod.mostrar_datos()
   print("Precio",prod.calcular_precio_final())

total_inventario=0
for prod in productos:
    total_por_unidad = prod.get_stock()*prod.calcular_precio_final()
    total_inventario = total_inventario + total_por_unidad
print("total inventario:",total_inventario)

el_mayor_precio=0
el_mayor_nombre= ""
for prod in productos:
    if prod.calcular_precio_final() > el_mayor_precio:
        el_mayor_precio = prod.calcular_precio_final()
        el_mayor_nombre = prod.nombre
print(el_mayor_nombre,":",el_mayor_precio)

#Respuestas
#heredar un metodo usa el metodo como esta en la clase padre y sobreescribirlo lo modifica para adaptarlo a algo especifico

#puede hacer eso por el polimorfismo, cada tipo tiene el mismo metodo pero modificado

#super().__init__(...) en cada clase hija inicializa los atributos de la clase padre

#La diferencia es que vender(5) resta al stock 5,reponer(5) agrega 5 al stock y set_stock(5) pone el stock en 5

#encapsulamiento => self.__stock = 0, herencia => remera_azul.vender(4), polimorfismo => print(prod.calcular_precio_final())




