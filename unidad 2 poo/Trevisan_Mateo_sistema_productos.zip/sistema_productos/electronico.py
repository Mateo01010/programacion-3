from producto import Producto
class Electronico(Producto):
    def __init__(self, nombre, precio, stock, garantia):
        super().__init__(nombre,"Electronico",precio,stock)
        self.garantia_meses = garantia
    
    def mostrar_garantia(self):
        print("Garantia:", self.garantia_meses ,"meses")
    
    def calcular_precio_final(self):
        return self.precio * 1.05
